﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ComputationalMethods
{
    public partial class CM : Form
    {
        MethodOfShooting MS;
        MethodRungKutta MRK;
        TrueFunction TF;
        

        public CM()
        {
            InitializeComponent();
            MS = new MethodOfShooting();
            MRK = new MethodRungKutta();
            TF = new TrueFunction();
        }

        private void PaintForm(object sender, PaintEventArgs e)
        {
            LN.Location = new Point(Convert.ToInt32(ClientSize.Width - 121), Convert.ToInt32(ClientSize.Height - 109));
            TBN.Location = new Point(Convert.ToInt32(ClientSize.Width - 121), Convert.ToInt32(ClientSize.Height - 88));
            Calculate.Location = new Point(Convert.ToInt32(ClientSize.Width - 121), Convert.ToInt32(ClientSize.Height - 66));
        }

        private void Calculate_Click(object sender, EventArgs e)
        {
            Graph.Series[0].Points.Clear();
            Graph.Series[1].Points.Clear();
            Graph.Series[2].Points.Clear();
            Graph.Series[3].Points.Clear();
            Graph.Series[4].Points.Clear();
            Graph.Series[5].Points.Clear();

            if (TBN.Text != "")
            {
                int N = Convert.ToInt32(TBN.Text);
                MS.EditN(N); MS.Calculate();
                MRK.EditN(N); MRK.Calculate();
                TF.EditN(N); TF.Calculate();

                for (int i = 0; i <= N; i++)
                {
                    Graph.Series[0].Points.AddXY(TF['X', i], TF['Y', i]);
                    Graph.Series[1].Points.AddXY(TF['X', i], TF['Z', i]);
                    Graph.Series[2].Points.AddXY(MS['X', i], MS['Y', i]);
                    Graph.Series[3].Points.AddXY(MS['X', i], MS['Z', i]);
                }
            }
        }
    }
}

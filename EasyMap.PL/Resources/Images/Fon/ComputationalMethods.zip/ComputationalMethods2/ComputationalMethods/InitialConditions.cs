﻿using System;

namespace ComputationalMethods
{
    partial class InitialConditions
    {
        public double A, B;
        public double[] X, Y, Z;
        public int N;
        public double H;

        public double FuncY(double X, double Y, double Z) => Z;
        public double FuncYY(double X, double Y, double Z) => 0.0;
        public double FuncYZ(double X, double Y, double Z) => 1.0;

        public double FuncZ(double X, double Y, double Z) => ( Math.Pow(Z, 2) / Y ) + ( Z / X );
        public double FuncZY(double X, double Y, double Z) => (-1.0) * ( Math.Pow(Z, 2) / Math.Pow(Y, 2) );
        public double FuncZZ(double X, double Y, double Z) => (1.0 / X) + ((2.0 * Z) / Y);

        public InitialConditions() { this.N = 0; InitIC(); }
        public InitialConditions(int N) { this.N = N; InitIC(); }
        public void EditN(int N) { this.N = N; InitIC(); }

        private void InitIC()
        {
            A = 1.0; B = 2.0;

            X = new double[N + 1];
            Y = new double[N + 1];
            Z = new double[N + 1];

            H = (B - A) / Convert.ToDouble(N);

            for (int i = 0; i <= N; ++i) { X[i] = A + i * H; Y[i] = 0.0; Z[i] = 0.0; }

            Y[0] = Math.E;
            Z[0] = 2.0 * Math.E;
        }

        public void WriteConsole()
        {
            for (int i = 0; i <= N; ++i) Console.WriteLine("#" + i + " : X = " + X[i] + " : Y = " + Y[i] + " : Z = " + Z[i]);
        }

        public double this[char type, int index]
        {
            get
            {
                if (index <= N)
                {
                    if (type == 'X') return X[index];
                    else if (type == 'Y') return Y[index];
                    else if (type == 'Z') return Z[index];
                }
                
                return 0;
            }
            private set { }
        }

    }

    partial class MethodOfShooting : InitialConditions
    {
        public MethodOfShooting() : base() { }
        public MethodOfShooting(int N) : base() { }
        private double TestZ = 4 * Math.Pow(Math.E, 4);
        private double Shoot = Math.E;
        private double Top = 0, Bottom = 0;
        private MethodRungKutta MRK = new MethodRungKutta();

        public void Calculate()
        {
            Console.WriteLine("Calculate: " + Math.E);
            MRK.EditN(this.N);
            Console.WriteLine("Calculate: Start Shooting");
            Shooting();
            Console.WriteLine("Calculate: End Shooting");
            Console.WriteLine(Top + " : " + Bottom);
            Console.WriteLine("Calculate: Start MethodBisection");
            MRK.Z[0] = MethodBisection();
            Console.WriteLine("Calculate: End MethodBisection");
            Console.WriteLine("Calculate: Start Calculate");
            MRK.Calculate();
            Console.WriteLine("Calculate: End Calculate");
            this.Y = MRK.Y; this.Z = MRK.Z;
        }

        private void Shooting()
        {
            // Top
            MRK.Z[0] = Top;
            do { MRK.Z[0] += Shoot; MRK.Calculate(); } while (MRK.Z[MRK.N] < TestZ);
            Top = MRK.Z[0];
            // Bottom
            MRK.Z[0] = Bottom;
            do { MRK.Z[0] -= Shoot; MRK.Calculate(); } while (MRK.Z[MRK.N] > TestZ);
            Bottom = MRK.Z[0];
        }

        private double MethodBisection()
        {
            double Z;
            int StopN = 1000;
            do
            {
                StopN--;
                Z = (Top + Bottom) / 2;
                Console.WriteLine("N: " + StopN + " Z: " + Z);
                MRK.Z[0] = Z; MRK.Calculate();
                if (MRK.Z[MRK.N] < TestZ) Bottom = Z;
                else if (MRK.Z[MRK.N] > TestZ) Top = Z;
            } while ((TestZ > MRK.Z[MRK.N] + 0.0001 || TestZ < MRK.Z[MRK.N] - 0.001) && StopN > 1000);
            Console.WriteLine("TestZ: " + TestZ + " MRK: " + MRK.Z[MRK.N]);
            return Z;
        }
    }

    partial class MethodRungKutta : InitialConditions
    {
        public MethodRungKutta() : base() {  }
        public MethodRungKutta(int N) : base(N) { }

        public void Calculate()
        {
            for (int i = 1; i <= N; ++i)
            {
                double YK1 = FuncY(X[i - 1], Y[i - 1], Z[i - 1]);
                double ZK1 = FuncZ(X[i - 1], Y[i - 1], Z[i - 1]);

                double YK2 = FuncY(X[i - 1] + H / 2.0, Y[i - 1] + H * YK1 / 2.0, Z[i - 1] + H * ZK1 / 2.0);
                double ZK2 = FuncZ(X[i - 1] + H / 2.0, Y[i - 1] + H * YK1 / 2.0, Z[i - 1] + H * ZK1 / 2.0);

                double YK3 = FuncY(X[i - 1] + H / 2.0, Y[i - 1] + H * YK2 / 2.0, Z[i - 1] + H * ZK2 / 2.0);
                double ZK3 = FuncZ(X[i - 1] + H / 2.0, Y[i - 1] + H * YK2 / 2.0, Z[i - 1] + H * ZK2 / 2.0);

                double YK4 = FuncY(X[i - 1] + H, Y[i - 1] + H * YK3, Z[i - 1] + H * ZK3);
                double ZK4 = FuncZ(X[i - 1] + H, Y[i - 1] + H * YK3, Z[i - 1] + H * ZK3);

                Y[i] = Y[i - 1] + H * (YK1 + 2.0 * YK2 + 2.0 * YK3 + YK4) / 6.0;
                Z[i] = Z[i - 1] + H * (ZK1 + 2.0 * ZK2 + 2.0 * ZK3 + ZK4) / 6.0;

            }
        }
    }
    
    partial class TrueFunction : InitialConditions
    {
        public TrueFunction() : base() { }
        public TrueFunction(int N) : base(N) { }

        public void Calculate()
        {
            for (int i = 0; i <= N; ++i)
            {
                Y[i] = Math.Pow(Math.E, Math.Pow(X[i], 2));
                Z[i] = 2 * X[i] * Y[i];
            }
        }
    }
}